import {
  LayoutTemplate,
  Video,
  Sparkles,
  Terminal,
  Megaphone,
  Wallet,
  QrCode,
  ShieldCheck,
  LayoutDashboard,
  Film,
  Code2,
  Braces,
  GitBranch,
  Boxes,
  type LucideIcon,
} from "lucide-react";

export type ModuleStatus = "aktif" | "yakinda" | "beta";

export interface SiteModule {
  id: string;
  href: string;
  title: string;
  shortTitle: string;
  description: string;
  icon: LucideIcon;
  status: ModuleStatus;
  paid: boolean;
  priceLabel?: string;
  accent: "cyan" | "violet" | "amber";
}

/**
 * Tek kaynak: yeni bir modül/sayfa eklemek istediğinde
 * sadece bu listeye bir kayıt ekle. Navigasyon, ana sayfa
 * kartları ve fiyatlandırma sayfası otomatik güncellenir.
 */
export const SITE_MODULES: SiteModule[] = [
  {
    id: "magaza",
    href: "/magaza",
    title: "Web Şablonları Mağazası",
    shortTitle: "Web Şablonları",
    description: "Hazır web sitesi şablonları — indir, özelleştir, yayına al.",
    icon: LayoutTemplate,
    status: "aktif",
    paid: true,
    priceLabel: "₺149'dan başlayan",
    accent: "cyan",
  },
  {
    id: "ai-video",
    href: "/ai-video",
    title: "Yapay Zeka Video Üretici",
    shortTitle: "AI Video",
    description: "Metinden veya senaryodan otomatik video üretimi.",
    icon: Video,
    status: "beta",
    paid: true,
    priceLabel: "Kredi bazlı",
    accent: "violet",
  },
  {
    id: "ai-karakter",
    href: "/ai-karakter",
    title: "AI Karakter & Çizgi Film Stüdyosu",
    shortTitle: "AI Karakter",
    description: "Resimden çizgi film karakteri üret, animasyonlu sahneler oluştur.",
    icon: Film,
    status: "beta",
    paid: true,
    priceLabel: "Kredi bazlı",
    accent: "violet",
  },
  {
    id: "gelistirici-araclari",
    href: "/gelistirici-araclari",
    title: "Geliştirici Araçları",
    shortTitle: "Dev Araçları",
    description: "Kod editörü, API test merkezi, otomasyon betikleri ve daha fazlası.",
    icon: Terminal,
    status: "aktif",
    paid: false,
    accent: "cyan",
  },
  {
    id: "reklam",
    href: "/reklam",
    title: "Ücretli Reklam Ekranı",
    shortTitle: "Reklam Ekranı",
    description: "Platform içi öne çıkan ürün/içerik reklam alanları yönetimi.",
    icon: Megaphone,
    status: "aktif",
    paid: true,
    priceLabel: "₺99/hafta'dan",
    accent: "amber",
  },
  {
    id: "fiyatlandirma",
    href: "/fiyatlandirma",
    title: "Fiyatlandırma & Paketler",
    shortTitle: "Fiyatlandırma",
    description: "Tüm ücretli modüllerin paket ve kredi fiyatları.",
    icon: Wallet,
    status: "aktif",
    paid: false,
    accent: "cyan",
  },
  {
    id: "odeme",
    href: "/odeme",
    title: "Ödeme Merkezi",
    shortTitle: "Ödeme",
    description: "Kart ile ödeme ve QR kod ile ödeme seçenekleri.",
    icon: QrCode,
    status: "aktif",
    paid: false,
    accent: "cyan",
  },
];

export const DEV_TOOL_PAGES = [
  {
    id: "kod-editoru",
    title: "Kod Editörü",
    description: "Tarayıcı içi çoklu dil kod editörü ve çalıştırıcı.",
    icon: Code2,
  },
  {
    id: "api-test",
    title: "API Test Merkezi",
    description: "REST/JSON API isteklerini test et, yanıtları incele.",
    icon: Braces,
  },
  {
    id: "otomasyon",
    title: "Otomasyon Betikleri",
    description: "Video render, dosya işleme ve zamanlanmış görevler.",
    icon: GitBranch,
  },
  {
    id: "bilesen-kutuphanesi",
    title: "Bileşen Kütüphanesi",
    description: "Yeniden kullanılabilir UI bileşenleri ve şablon parçaları.",
    icon: Boxes,
  },
];

export const PRIMARY_NAV = [
  { href: "/", label: "Komuta Merkezi", icon: LayoutDashboard },
  ...SITE_MODULES.map((m) => ({ href: m.href, label: m.shortTitle, icon: m.icon })),
  { href: "/admin", label: "Yönetim Paneli", icon: ShieldCheck },
];

export const ACCENT_HEX: Record<SiteModule["accent"], string> = {
  cyan: "#00e5ff",
  violet: "#8b5cf6",
  amber: "#f5a623",
};

export const STATUS_LABEL: Record<ModuleStatus, string> = {
  aktif: "AKTİF",
  beta: "BETA",
  yakinda: "YAKINDA",
};

export const STATUS_COLOR: Record<ModuleStatus, string> = {
  aktif: "#22c55e",
  beta: "#f5a623",
  yakinda: "#5b6b85",
};

export const SPARKLES_ICON = Sparkles;
