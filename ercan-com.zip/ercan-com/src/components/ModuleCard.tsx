import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { ACCENT_HEX, STATUS_COLOR, STATUS_LABEL, type SiteModule } from "@/lib/modules";

export default function ModuleCard({ mod }: { mod: SiteModule }) {
  const Icon = mod.icon;
  const accent = ACCENT_HEX[mod.accent];

  return (
    <Link
      href={mod.href}
      className="group relative flex flex-col gap-4 p-5 rounded-xl border transition-all duration-200 hover:-translate-y-0.5"
      style={{
        background: "var(--panel)",
        borderColor: "var(--line)",
      }}
    >
      <div className="flex items-start justify-between">
        <div
          className="w-10 h-10 rounded-lg flex items-center justify-center"
          style={{ background: `${accent}1a`, border: `1px solid ${accent}33` }}
        >
          <Icon size={19} strokeWidth={1.75} style={{ color: accent }} />
        </div>
        <ArrowUpRight
          size={16}
          className="opacity-0 group-hover:opacity-100 transition-opacity"
          style={{ color: "var(--text-low)" }}
        />
      </div>

      <div className="flex-1">
        <div className="flex items-center gap-2 mb-1.5">
          <h3 className="font-display font-medium text-[15px]" style={{ color: "var(--text-hi)" }}>
            {mod.title}
          </h3>
        </div>
        <p className="text-[13px] leading-relaxed" style={{ color: "var(--text-mid)" }}>
          {mod.description}
        </p>
      </div>

      <div className="flex items-center justify-between pt-3 border-t" style={{ borderColor: "var(--line)" }}>
        <span
          className="font-mono text-[10px] tracking-wider px-2 py-0.5 rounded"
          style={{ color: STATUS_COLOR[mod.status], background: `${STATUS_COLOR[mod.status]}14` }}
        >
          {STATUS_LABEL[mod.status]}
        </span>
        {mod.paid ? (
          <span className="font-mono text-[11px]" style={{ color: "var(--amber)" }}>
            {mod.priceLabel ?? "Ücretli"}
          </span>
        ) : (
          <span className="font-mono text-[11px]" style={{ color: "var(--text-low)" }}>
            Ücretsiz
          </span>
        )}
      </div>
    </Link>
  );
}
