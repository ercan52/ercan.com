"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Menu, X } from "lucide-react";
import { PRIMARY_NAV } from "@/lib/modules";
import { usePathname } from "next/navigation";

export default function TopBar() {
  const [now, setNow] = useState<Date | null>(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    setNow(new Date());
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const timeStr = now
    ? now.toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit", second: "2-digit" })
    : "--:--:--";
  const dateStr = now
    ? now.toLocaleDateString("tr-TR", { day: "2-digit", month: "2-digit", year: "numeric" })
    : "--.--.----";

  return (
    <>
      <header
        className="sticky top-0 z-40 flex items-center justify-between gap-4 px-4 lg:px-6 h-14 border-b backdrop-blur-sm"
        style={{ background: "rgba(13,19,32,0.92)", borderColor: "var(--line)" }}
      >
        <div className="flex items-center gap-3">
          <button
            onClick={() => setMobileOpen(true)}
            className="lg:hidden p-1.5 rounded-md"
            style={{ color: "var(--text-mid)" }}
            aria-label="Menüyü aç"
          >
            <Menu size={20} />
          </button>
          <span className="font-mono text-xs hidden sm:inline" style={{ color: "var(--text-low)" }}>
            DURUM: <span style={{ color: "var(--ok)" }}>ÇEVRİMİÇİ</span>
          </span>
        </div>

        <div className="flex items-center gap-4 font-mono text-xs" style={{ color: "var(--text-mid)" }}>
          <span className="hidden sm:inline" style={{ color: "var(--text-low)" }}>{dateStr}</span>
          <span style={{ color: "var(--cyan)" }}>{timeStr}</span>
        </div>
      </header>

      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="absolute inset-0"
            style={{ background: "rgba(6,9,15,0.8)" }}
            onClick={() => setMobileOpen(false)}
          />
          <div
            className="absolute left-0 top-0 h-full w-72 flex flex-col border-r"
            style={{ background: "var(--panel)", borderColor: "var(--line)" }}
          >
            <div className="flex items-center justify-between px-5 py-5 border-b" style={{ borderColor: "var(--line)" }}>
              <span className="font-display font-semibold text-sm" style={{ color: "var(--text-hi)" }}>
                ercan.com
              </span>
              <button onClick={() => setMobileOpen(false)} style={{ color: "var(--text-mid)" }} aria-label="Menüyü kapat">
                <X size={20} />
              </button>
            </div>
            <nav className="flex-1 overflow-y-auto py-3 px-3 space-y-0.5">
              {PRIMARY_NAV.map((item) => {
                const active = pathname === item.href;
                const Icon = item.icon;
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={() => setMobileOpen(false)}
                    className="flex items-center gap-3 px-3 py-2.5 rounded-md text-sm"
                    style={{
                      background: active ? "var(--panel-raised)" : "transparent",
                      color: active ? "var(--text-hi)" : "var(--text-mid)",
                    }}
                  >
                    <Icon size={17} strokeWidth={1.75} style={{ color: active ? "var(--cyan)" : "var(--text-low)" }} />
                    <span>{item.label}</span>
                  </Link>
                );
              })}
            </nav>
          </div>
        </div>
      )}
    </>
  );
}
