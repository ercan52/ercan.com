import { type LucideIcon } from "lucide-react";

export default function PageHeader({
  icon: Icon,
  eyebrow,
  title,
  description,
  accent = "#00e5ff",
}: {
  icon: LucideIcon;
  eyebrow: string;
  title: string;
  description: string;
  accent?: string;
}) {
  return (
    <div className="mb-8 pb-6 border-b" style={{ borderColor: "var(--line)" }}>
      <div className="flex items-center gap-2 mb-3">
        <span
          className="font-mono text-[11px] tracking-[0.15em] px-2 py-0.5 rounded"
          style={{ color: accent, background: `${accent}14` }}
        >
          {eyebrow}
        </span>
      </div>
      <div className="flex items-center gap-3">
        <div
          className="w-11 h-11 rounded-lg flex items-center justify-center shrink-0"
          style={{ background: `${accent}1a`, border: `1px solid ${accent}33` }}
        >
          <Icon size={21} strokeWidth={1.75} style={{ color: accent }} />
        </div>
        <h1 className="font-display font-semibold text-2xl sm:text-[28px]" style={{ color: "var(--text-hi)" }}>
          {title}
        </h1>
      </div>
      <p className="mt-3 text-sm leading-relaxed max-w-2xl" style={{ color: "var(--text-mid)" }}>
        {description}
      </p>
    </div>
  );
}
