"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { PRIMARY_NAV } from "@/lib/modules";

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <aside
      className="hidden lg:flex flex-col w-64 shrink-0 h-screen sticky top-0 border-r"
      style={{ background: "var(--panel)", borderColor: "var(--line)" }}
    >
      <div className="px-5 py-6 border-b" style={{ borderColor: "var(--line)" }}>
        <Link href="/" className="flex items-center gap-2.5">
          <div
            className="w-9 h-9 rounded-md flex items-center justify-center font-display font-bold text-sm"
            style={{
              background: "linear-gradient(135deg, var(--cyan) 0%, var(--violet) 100%)",
              color: "#06090f",
            }}
          >
            EA
          </div>
          <div>
            <div className="font-display font-semibold text-[15px] leading-tight" style={{ color: "var(--text-hi)" }}>
              ercan.com
            </div>
            <div className="font-mono text-[10px] tracking-wider" style={{ color: "var(--text-low)" }}>
              KOMUTA MERKEZİ
            </div>
          </div>
        </Link>
      </div>

      <nav className="flex-1 overflow-y-auto py-3 px-3 space-y-0.5">
        {PRIMARY_NAV.map((item) => {
          const active = pathname === item.href;
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              className="flex items-center gap-3 px-3 py-2.5 rounded-md text-sm transition-colors relative"
              style={{
                background: active ? "var(--panel-raised)" : "transparent",
                color: active ? "var(--text-hi)" : "var(--text-mid)",
              }}
            >
              {active && (
                <span
                  className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-5 rounded-full"
                  style={{ background: "var(--cyan)" }}
                />
              )}
              <Icon size={17} strokeWidth={1.75} style={{ color: active ? "var(--cyan)" : "var(--text-low)" }} />
              <span>{item.label}</span>
            </Link>
          );
        })}
      </nav>

      <div className="px-4 py-4 border-t" style={{ borderColor: "var(--line)" }}>
        <div className="font-mono text-[10px] leading-relaxed" style={{ color: "var(--text-low)" }}>
          SİSTEM DURUMU<br />
          <span style={{ color: "var(--ok)" }}>● ÇEVRİMİÇİ</span>
        </div>
      </div>
    </aside>
  );
}
