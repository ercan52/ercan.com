import Link from "next/link";
import { SITE_MODULES } from "@/lib/modules";
import ModuleCard from "@/components/ModuleCard";
import { Activity, Users, CreditCard, Layers } from "lucide-react";

const STATS = [
  { label: "AKTİF MODÜL", value: SITE_MODULES.filter((m) => m.status !== "yakinda").length.toString(), icon: Layers },
  { label: "ÜCRETLİ HİZMET", value: SITE_MODULES.filter((m) => m.paid).length.toString(), icon: CreditCard },
  { label: "SİSTEM YÜKÜ", value: "%12", icon: Activity },
  { label: "PANEL ERİŞİMİ", value: "1 Yönetici", icon: Users },
];

export default function HomePage() {
  return (
    <div>
      {/* Hero */}
      <section className="mb-10 pb-8 border-b" style={{ borderColor: "var(--line)" }}>
        <div className="flex items-center gap-2 mb-4">
          <span className="w-1.5 h-1.5 rounded-full" style={{ background: "var(--ok)" }} />
          <span className="font-mono text-[11px] tracking-[0.15em]" style={{ color: "var(--text-low)" }}>
            ERCANAYDOĞDU İŞLETİM SİSTEMİ
          </span>
        </div>
        <h1 className="font-display font-semibold text-3xl sm:text-4xl leading-tight mb-3" style={{ color: "var(--text-hi)" }}>
          Komuta Merkezi
        </h1>
        <p className="text-sm sm:text-[15px] max-w-xl leading-relaxed" style={{ color: "var(--text-mid)" }}>
          Web şablonları, yapay zeka video & karakter üretimi, geliştirici araçları, reklam
          alanı ve ödeme sistemini tek bir panelden yönet. Yeni bir hizmet eklemek istediğinde
          buraya bir modül daha kazınır.
        </p>
        <div className="flex flex-wrap gap-3 mt-6">
          <Link
            href="/magaza"
            className="font-medium text-sm px-5 py-2.5 rounded-md transition-opacity hover:opacity-90"
            style={{ background: "var(--cyan)", color: "#06090f" }}
          >
            Mağazaya göz at
          </Link>
          <Link
            href="/admin"
            className="font-medium text-sm px-5 py-2.5 rounded-md border transition-colors"
            style={{ borderColor: "var(--line)", color: "var(--text-hi)" }}
          >
            Yönetim paneline git
          </Link>
        </div>
      </section>

      {/* Stats strip */}
      <section className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-10">
        {STATS.map((s) => {
          const Icon = s.icon;
          return (
            <div
              key={s.label}
              className="p-4 rounded-lg border"
              style={{ background: "var(--panel)", borderColor: "var(--line)" }}
            >
              <Icon size={16} strokeWidth={1.75} style={{ color: "var(--cyan)" }} />
              <div className="font-display font-semibold text-xl mt-3" style={{ color: "var(--text-hi)" }}>
                {s.value}
              </div>
              <div className="font-mono text-[10px] tracking-wider mt-1" style={{ color: "var(--text-low)" }}>
                {s.label}
              </div>
            </div>
          );
        })}
      </section>

      {/* Modules grid */}
      <section>
        <div className="flex items-center justify-between mb-5">
          <h2 className="font-display font-medium text-lg" style={{ color: "var(--text-hi)" }}>
            Modüller
          </h2>
          <span className="font-mono text-[11px]" style={{ color: "var(--text-low)" }}>
            {SITE_MODULES.length} modül kayıtlı
          </span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {SITE_MODULES.map((mod) => (
            <ModuleCard key={mod.id} mod={mod} />
          ))}
        </div>
      </section>
    </div>
  );
}
