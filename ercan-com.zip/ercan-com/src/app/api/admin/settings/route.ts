import { NextRequest, NextResponse } from "next/server";
import fs from "fs";
import path from "path";

/**
 * Basit dosya tabanlı ayar saklama.
 * ÜRETİM NOTU: Gerçek canlı ortamda bu dosyanın yerine
 * şifrelenmiş bir veritabanı (örn. Postgres + KMS) veya
 * platformun secret-manager servisi (Vercel Env Vars,
 * Modal Secrets vb.) kullanılmalı. Anahtarlar asla
 * git deposuna veya istemci tarafına gönderilmemelidir.
 */
const SETTINGS_PATH = path.join(process.cwd(), ".data", "settings.json");

interface Settings {
  iyzicoApiKey?: string;
  iyzicoSecretKey?: string;
  paytrMerchantId?: string;
  videoAiProvider?: string;
  videoAiApiKey?: string;
  imageAiProvider?: string;
  imageAiApiKey?: string;
}

function readSettings(): Settings {
  try {
    if (!fs.existsSync(SETTINGS_PATH)) return {};
    return JSON.parse(fs.readFileSync(SETTINGS_PATH, "utf-8"));
  } catch {
    return {};
  }
}

function writeSettings(settings: Settings) {
  const dir = path.dirname(SETTINGS_PATH);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(SETTINGS_PATH, JSON.stringify(settings, null, 2));
}

function mask(value?: string) {
  if (!value) return "";
  if (value.length <= 6) return "••••••";
  return `${value.slice(0, 4)}••••${value.slice(-2)}`;
}

export async function GET() {
  const settings = readSettings();
  return NextResponse.json({
    iyzicoApiKey: mask(settings.iyzicoApiKey),
    iyzicoSecretKey: mask(settings.iyzicoSecretKey),
    paytrMerchantId: mask(settings.paytrMerchantId),
    videoAiProvider: settings.videoAiProvider ?? "",
    videoAiApiKey: mask(settings.videoAiApiKey),
    imageAiProvider: settings.imageAiProvider ?? "",
    imageAiApiKey: mask(settings.imageAiApiKey),
    connected: {
      iyzico: Boolean(settings.iyzicoApiKey && settings.iyzicoSecretKey),
      paytr: Boolean(settings.paytrMerchantId),
      videoAi: Boolean(settings.videoAiApiKey),
      imageAi: Boolean(settings.imageAiApiKey),
    },
  });
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const current = readSettings();
  const updated: Settings = { ...current };

  const fields: (keyof Settings)[] = [
    "iyzicoApiKey",
    "iyzicoSecretKey",
    "paytrMerchantId",
    "videoAiProvider",
    "videoAiApiKey",
    "imageAiProvider",
    "imageAiApiKey",
  ];

  for (const f of fields) {
    if (typeof body[f] === "string" && body[f].length > 0) {
      updated[f] = body[f];
    }
  }

  writeSettings(updated);
  return NextResponse.json({ ok: true });
}
