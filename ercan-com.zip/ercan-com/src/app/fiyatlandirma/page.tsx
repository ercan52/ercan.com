import { Wallet, Check } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import Link from "next/link";

const PACKAGES = [
  {
    name: "Başlangıç",
    price: "₺99",
    period: "/ay",
    credits: "20 kredi",
    features: ["Web şablonlarına erişim", "20 AI üretim kredisi", "Standart render kalitesi", "E-posta destek"],
    highlight: false,
  },
  {
    name: "Stüdyo",
    price: "₺299",
    period: "/ay",
    credits: "80 kredi",
    features: ["Tüm şablonlara erişim", "80 AI üretim kredisi", "4K render kalitesi", "Öncelikli destek", "Reklam alanı %20 indirim"],
    highlight: true,
  },
  {
    name: "Kurumsal",
    price: "₺799",
    period: "/ay",
    credits: "300 kredi",
    features: ["Sınırsız şablon erişimi", "300 AI üretim kredisi", "4K + Shorts otomatik render", "Özel reklam alanı", "Telefon desteği"],
    highlight: false,
  },
];

export default function FiyatlandirmaPage() {
  return (
    <div>
      <PageHeader
        icon={Wallet}
        eyebrow="MODÜL 06"
        title="Fiyatlandırma & Paketler"
        description="Kredi paketini seç, ödemeni yap, AI video ve karakter üretimine hemen başla. Tüm fiyatlar gösterge niteliğindedir, yönetim panelinden düzenlenebilir."
      />

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        {PACKAGES.map((p) => (
          <div
            key={p.name}
            className="rounded-xl border p-6 flex flex-col relative"
            style={{
              background: p.highlight ? "var(--panel-raised)" : "var(--panel)",
              borderColor: p.highlight ? "var(--cyan)" : "var(--line)",
            }}
          >
            {p.highlight && (
              <span
                className="absolute -top-3 left-6 font-mono text-[10px] tracking-wider px-2.5 py-1 rounded-full"
                style={{ background: "var(--cyan)", color: "#06090f" }}
              >
                EN POPÜLER
              </span>
            )}
            <h3 className="font-display font-medium text-base mb-1" style={{ color: "var(--text-hi)" }}>
              {p.name}
            </h3>
            <div className="flex items-baseline gap-1 mb-1">
              <span className="font-display font-semibold text-3xl" style={{ color: "var(--text-hi)" }}>{p.price}</span>
              <span className="text-sm" style={{ color: "var(--text-low)" }}>{p.period}</span>
            </div>
            <span className="font-mono text-xs mb-5" style={{ color: "var(--cyan)" }}>{p.credits}</span>

            <ul className="space-y-2.5 mb-6 flex-1">
              {p.features.map((f) => (
                <li key={f} className="flex items-start gap-2 text-xs" style={{ color: "var(--text-mid)" }}>
                  <Check size={14} className="shrink-0 mt-0.5" style={{ color: "var(--ok)" }} />
                  {f}
                </li>
              ))}
            </ul>

            <Link
              href="/odeme"
              className="text-center text-sm font-medium py-2.5 rounded-md transition-opacity hover:opacity-90"
              style={{
                background: p.highlight ? "var(--cyan)" : "var(--panel-raised)",
                color: p.highlight ? "#06090f" : "var(--text-hi)",
                border: p.highlight ? "none" : "1px solid var(--line)",
              }}
            >
              Bu paketi seç
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
}
