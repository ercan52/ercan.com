import { Video, Sparkles, Settings, Coins } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import Link from "next/link";

export default function AiVideoPage() {
  return (
    <div>
      <PageHeader
        icon={Video}
        eyebrow="MODÜL 02 · BETA"
        title="Yapay Zeka Video Üretici"
        description="Senaryo veya metin girerek otomatik video üret. Bu modülün çalışması için yönetim panelinden bir video üretim servisinin (örn. Runway, Pika, Kling) API anahtarını bağlaman gerekiyor."
        accent="#8b5cf6"
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <div className="p-5 rounded-xl border space-y-4" style={{ background: "var(--panel)", borderColor: "var(--line)" }}>
            <div>
              <label className="font-mono text-[11px] tracking-wider block mb-2" style={{ color: "var(--text-low)" }}>
                SENARYO / METİN
              </label>
              <textarea
                rows={5}
                placeholder="Videonun konusunu, sahnelerini ve atmosferini buraya yaz..."
                className="w-full rounded-lg border px-3.5 py-3 text-sm resize-none focus:outline-none"
                style={{ background: "var(--panel-raised)", borderColor: "var(--line)", color: "var(--text-hi)" }}
              />
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div>
                <label className="font-mono text-[10px] tracking-wider block mb-1.5" style={{ color: "var(--text-low)" }}>
                  FORMAT
                </label>
                <select
                  className="w-full rounded-lg border px-3 py-2 text-sm focus:outline-none"
                  style={{ background: "var(--panel-raised)", borderColor: "var(--line)", color: "var(--text-hi)" }}
                >
                  <option>16:9 (4K Yatay)</option>
                  <option>9:16 (Shorts/Dikey)</option>
                  <option>1:1 (Kare)</option>
                </select>
              </div>
              <div>
                <label className="font-mono text-[10px] tracking-wider block mb-1.5" style={{ color: "var(--text-low)" }}>
                  SÜRE
                </label>
                <select
                  className="w-full rounded-lg border px-3 py-2 text-sm focus:outline-none"
                  style={{ background: "var(--panel-raised)", borderColor: "var(--line)", color: "var(--text-hi)" }}
                >
                  <option>15 sn</option>
                  <option>30 sn</option>
                  <option>60 sn</option>
                </select>
              </div>
              <div>
                <label className="font-mono text-[10px] tracking-wider block mb-1.5" style={{ color: "var(--text-low)" }}>
                  STİL
                </label>
                <select
                  className="w-full rounded-lg border px-3 py-2 text-sm focus:outline-none"
                  style={{ background: "var(--panel-raised)", borderColor: "var(--line)", color: "var(--text-hi)" }}
                >
                  <option>Sinematik</option>
                  <option>Sci-Fi</option>
                  <option>Belgesel</option>
                </select>
              </div>
            </div>

            <button
              className="w-full flex items-center justify-center gap-2 rounded-lg py-3 font-medium text-sm transition-opacity hover:opacity-90"
              style={{ background: "var(--violet)", color: "#fff" }}
            >
              <Sparkles size={16} />
              Videoyu Üret (3 kredi)
            </button>
          </div>

          <div
            className="p-4 rounded-xl border font-mono text-[12px] leading-relaxed"
            style={{ background: "var(--panel)", borderColor: "var(--line)", color: "var(--text-low)" }}
          >
            DURUM: Üretim servisi bağlı değil. Üretime başlamak için önce{" "}
            <Link href="/admin" className="underline" style={{ color: "var(--violet)" }}>
              yönetim panelinden
            </Link>{" "}
            bir video AI servis anahtarı tanımla.
          </div>
        </div>

        <div className="space-y-4">
          <div className="p-5 rounded-xl border" style={{ background: "var(--panel)", borderColor: "var(--line)" }}>
            <div className="flex items-center gap-2 mb-3">
              <Coins size={16} style={{ color: "var(--amber)" }} />
              <span className="font-display font-medium text-sm" style={{ color: "var(--text-hi)" }}>
                Kredi Bakiyesi
              </span>
            </div>
            <div className="font-display font-semibold text-2xl mb-1" style={{ color: "var(--text-hi)" }}>
              0 kredi
            </div>
            <Link href="/fiyatlandirma" className="text-xs underline" style={{ color: "var(--cyan)" }}>
              Kredi paketlerini gör →
            </Link>
          </div>

          <div className="p-5 rounded-xl border" style={{ background: "var(--panel)", borderColor: "var(--line)" }}>
            <div className="flex items-center gap-2 mb-3">
              <Settings size={16} style={{ color: "var(--text-mid)" }} />
              <span className="font-display font-medium text-sm" style={{ color: "var(--text-hi)" }}>
                Bağlı Servis
              </span>
            </div>
            <p className="text-xs leading-relaxed" style={{ color: "var(--text-mid)" }}>
              Henüz bir video üretim servisi bağlanmadı. Desteklenen servisler: Runway,
              Pika Labs, Kling AI. Bağlamak için yönetim paneline git.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
