import { Film, Upload, Sparkles, Settings, Share2 } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import Link from "next/link";

export default function AiKarakterPage() {
  return (
    <div>
      <PageHeader
        icon={Film}
        eyebrow="MODÜL 03 · BETA"
        title="AI Karakter & Çizgi Film Stüdyosu"
        description="Bir fotoğraf yükle, ondan çizgi film karakteri üret ve animasyonlu kısa sahneler oluştur. Bu modül de görsel/video üretim servisi anahtarına bağlıdır — yönetim panelinden tanımlanır."
        accent="#8b5cf6"
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upload + generate */}
        <div className="p-5 rounded-xl border space-y-4" style={{ background: "var(--panel)", borderColor: "var(--line)" }}>
          <h3 className="font-display font-medium text-sm" style={{ color: "var(--text-hi)" }}>
            1. Görsel yükle
          </h3>
          <div
            className="border-2 border-dashed rounded-xl py-10 flex flex-col items-center gap-3 cursor-pointer transition-colors"
            style={{ borderColor: "var(--line)" }}
          >
            <Upload size={24} strokeWidth={1.5} style={{ color: "var(--text-low)" }} />
            <span className="text-sm" style={{ color: "var(--text-mid)" }}>
              Resim sürükle veya tıkla
            </span>
            <span className="font-mono text-[10px]" style={{ color: "var(--text-low)" }}>
              JPG, PNG · maks 10MB
            </span>
          </div>

          <h3 className="font-display font-medium text-sm pt-2" style={{ color: "var(--text-hi)" }}>
            2. Karakter stilini seç
          </h3>
          <div className="grid grid-cols-3 gap-2">
            {["Anime", "Pixar Tarzı", "El Çizimi", "Piksel Sanat", "Komik Karikatür", "Sci-Fi"].map((s) => (
              <button
                key={s}
                className="text-xs py-2.5 rounded-lg border transition-colors"
                style={{ borderColor: "var(--line)", color: "var(--text-mid)", background: "var(--panel-raised)" }}
              >
                {s}
              </button>
            ))}
          </div>

          <button
            className="w-full flex items-center justify-center gap-2 rounded-lg py-3 font-medium text-sm transition-opacity hover:opacity-90 mt-2"
            style={{ background: "var(--violet)", color: "#fff" }}
          >
            <Sparkles size={16} />
            Karakteri Üret (2 kredi)
          </button>
        </div>

        {/* Preview / output */}
        <div className="space-y-4">
          <div
            className="aspect-square rounded-xl border flex items-center justify-center"
            style={{
              background: "linear-gradient(135deg, rgba(139,92,246,0.06) 0%, rgba(0,229,255,0.06) 100%)",
              borderColor: "var(--line)",
            }}
          >
            <div className="text-center">
              <Film size={32} strokeWidth={1.5} style={{ color: "var(--text-low)" }} className="mx-auto mb-3" />
              <p className="text-sm" style={{ color: "var(--text-low)" }}>
                Üretilen karakter burada görünecek
              </p>
            </div>
          </div>

          <div className="flex gap-3">
            <button
              disabled
              className="flex-1 flex items-center justify-center gap-2 rounded-lg py-2.5 text-sm border opacity-50 cursor-not-allowed"
              style={{ borderColor: "var(--line)", color: "var(--text-mid)" }}
            >
              <Share2 size={14} />
              Sosyal Medyada Paylaş
            </button>
          </div>

          <div
            className="p-4 rounded-xl border font-mono text-[11px] leading-relaxed"
            style={{ background: "var(--panel)", borderColor: "var(--line)", color: "var(--text-low)" }}
          >
            DURUM: Görsel üretim servisi bağlı değil.{" "}
            <Link href="/admin" className="underline" style={{ color: "var(--violet)" }}>
              Yönetim panelinden
            </Link>{" "}
            bağla.
          </div>
        </div>
      </div>

      <div
        className="mt-6 p-5 rounded-xl border flex items-start gap-3"
        style={{ background: "var(--panel)", borderColor: "var(--line)" }}
      >
        <Settings size={18} style={{ color: "var(--text-mid)" }} className="mt-0.5 shrink-0" />
        <div>
          <h4 className="font-display font-medium text-sm mb-1" style={{ color: "var(--text-hi)" }}>
            Sosyal medya paylaşımı hakkında önemli not
          </h4>
          <p className="text-xs leading-relaxed" style={{ color: "var(--text-mid)" }}>
            Üretilen video/karakterleri kendi hesaplarından (YouTube, TikTok, Instagram) paylaşmak için
            her platformun kendi resmi API onay sürecinden geçen bağlantı gerekir — bu, platformların
            kullanım şartlarının bir parçasıdır. "Tek tıkla otomatik paylaşım" sözü veren araçlar
            genellikle hesap askıya alma riski taşır. Burada içeriği üretip indirebilir, ardından
            yönetim panelinden bağladığın resmi platform API'leri üzerinden paylaşabilirsin.
          </p>
        </div>
      </div>
    </div>
  );
}
