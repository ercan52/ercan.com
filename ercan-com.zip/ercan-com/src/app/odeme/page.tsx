"use client";

import { useState } from "react";
import { QrCode, CreditCard, ShieldCheck, AlertTriangle } from "lucide-react";
import PageHeader from "@/components/PageHeader";

export default function OdemePage() {
  const [method, setMethod] = useState<"kart" | "qr">("kart");

  return (
    <div>
      <PageHeader
        icon={QrCode}
        eyebrow="MODÜL 07"
        title="Ödeme Merkezi"
        description="Kart ile veya QR kod ile ödeme yap. Gerçek tahsilat için yönetim panelinden bir ödeme sağlayıcısı (iyzico/PayTR) anahtarının tanımlanmış olması gerekir."
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          {/* method tabs */}
          <div className="flex gap-2 mb-5">
            <button
              onClick={() => setMethod("kart")}
              className="flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors"
              style={{
                background: method === "kart" ? "var(--cyan)" : "var(--panel)",
                color: method === "kart" ? "#06090f" : "var(--text-mid)",
                border: method === "kart" ? "none" : "1px solid var(--line)",
              }}
            >
              <CreditCard size={16} />
              Kart ile Öde
            </button>
            <button
              onClick={() => setMethod("qr")}
              className="flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors"
              style={{
                background: method === "qr" ? "var(--cyan)" : "var(--panel)",
                color: method === "qr" ? "#06090f" : "var(--text-mid)",
                border: method === "qr" ? "none" : "1px solid var(--line)",
              }}
            >
              <QrCode size={16} />
              QR Kod ile Öde
            </button>
          </div>

          {method === "kart" ? (
            <div className="p-6 rounded-xl border space-y-4" style={{ background: "var(--panel)", borderColor: "var(--line)" }}>
              <div>
                <label className="font-mono text-[11px] tracking-wider block mb-2" style={{ color: "var(--text-low)" }}>
                  KART ÜZERİNDEKİ AD
                </label>
                <input
                  type="text"
                  placeholder="AD SOYAD"
                  className="w-full rounded-lg border px-3.5 py-2.5 text-sm focus:outline-none"
                  style={{ background: "var(--panel-raised)", borderColor: "var(--line)", color: "var(--text-hi)" }}
                />
              </div>
              <div>
                <label className="font-mono text-[11px] tracking-wider block mb-2" style={{ color: "var(--text-low)" }}>
                  KART NUMARASI
                </label>
                <input
                  type="text"
                  placeholder="0000 0000 0000 0000"
                  className="w-full rounded-lg border px-3.5 py-2.5 text-sm font-mono focus:outline-none"
                  style={{ background: "var(--panel-raised)", borderColor: "var(--line)", color: "var(--text-hi)" }}
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-mono text-[11px] tracking-wider block mb-2" style={{ color: "var(--text-low)" }}>
                    SON KULLANMA
                  </label>
                  <input
                    type="text"
                    placeholder="AA/YY"
                    className="w-full rounded-lg border px-3.5 py-2.5 text-sm font-mono focus:outline-none"
                    style={{ background: "var(--panel-raised)", borderColor: "var(--line)", color: "var(--text-hi)" }}
                  />
                </div>
                <div>
                  <label className="font-mono text-[11px] tracking-wider block mb-2" style={{ color: "var(--text-low)" }}>
                    CVV
                  </label>
                  <input
                    type="text"
                    placeholder="123"
                    className="w-full rounded-lg border px-3.5 py-2.5 text-sm font-mono focus:outline-none"
                    style={{ background: "var(--panel-raised)", borderColor: "var(--line)", color: "var(--text-hi)" }}
                  />
                </div>
              </div>
              <button
                disabled
                className="w-full rounded-lg py-3 font-medium text-sm opacity-50 cursor-not-allowed"
                style={{ background: "var(--cyan)", color: "#06090f" }}
              >
                Ödemeyi Tamamla
              </button>
              <p className="font-mono text-[11px] flex items-start gap-2" style={{ color: "var(--text-low)" }}>
                <AlertTriangle size={13} className="shrink-0 mt-0.5" style={{ color: "var(--amber)" }} />
                Ödeme sağlayıcısı henüz bağlanmadı. Bu form, yönetim panelinden iyzico/PayTR
                anahtarı tanımlandıktan sonra gerçek tahsilat yapabilir.
              </p>
            </div>
          ) : (
            <div className="p-6 rounded-xl border flex flex-col items-center gap-4 text-center" style={{ background: "var(--panel)", borderColor: "var(--line)" }}>
              <div
                className="w-48 h-48 rounded-xl flex items-center justify-center border-2"
                style={{ borderColor: "var(--line)", background: "var(--panel-raised)" }}
              >
                <QrCode size={120} strokeWidth={1} style={{ color: "var(--text-low)" }} />
              </div>
              <p className="text-sm max-w-xs" style={{ color: "var(--text-mid)" }}>
                Bankan veya ödeme uygulamanla QR kodu okut. Bu kod, ödeme sağlayıcısı
                bağlandığında gerçek bir ödeme isteği üretir.
              </p>
              <p className="font-mono text-[11px] flex items-start gap-2" style={{ color: "var(--text-low)" }}>
                <AlertTriangle size={13} className="shrink-0 mt-0.5" style={{ color: "var(--amber)" }} />
                Şu an gösteri amaçlı statik kod. Gerçek QR ödeme için yönetim panelinden
                sağlayıcı tanımlanması gerekir.
              </p>
            </div>
          )}
        </div>

        <div className="p-5 rounded-xl border h-fit" style={{ background: "var(--panel)", borderColor: "var(--line)" }}>
          <div className="flex items-center gap-2 mb-3">
            <ShieldCheck size={16} style={{ color: "var(--ok)" }} />
            <span className="font-display font-medium text-sm" style={{ color: "var(--text-hi)" }}>
              Güvenlik
            </span>
          </div>
          <p className="text-xs leading-relaxed" style={{ color: "var(--text-mid)" }}>
            Kart bilgileri bu sunucuda saklanmaz. Gerçek bir ödeme sağlayıcısı bağlandığında
            tüm kart işlemleri doğrudan o sağlayıcının güvenli (PCI-DSS uyumlu) ortamında
            gerçekleşir.
          </p>
        </div>
      </div>
    </div>
  );
}
