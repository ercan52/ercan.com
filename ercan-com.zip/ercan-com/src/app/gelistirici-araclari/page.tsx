import { Terminal } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import { DEV_TOOL_PAGES } from "@/lib/modules";

export default function GelistiriciAraclariPage() {
  return (
    <div>
      <PageHeader
        icon={Terminal}
        eyebrow="MODÜL 04"
        title="Geliştirici Araçları"
        description="Kod yazma, API test etme ve otomasyon görevleri için tek panelden erişilebilen araç seti. Her araç bağımsız bir sayfa olarak büyütülebilir."
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {DEV_TOOL_PAGES.map((tool) => {
          const Icon = tool.icon;
          return (
            <div
              key={tool.id}
              className="p-5 rounded-xl border flex items-start gap-4"
              style={{ background: "var(--panel)", borderColor: "var(--line)" }}
            >
              <div
                className="w-10 h-10 rounded-lg flex items-center justify-center shrink-0"
                style={{ background: "rgba(0,229,255,0.1)", border: "1px solid rgba(0,229,255,0.2)" }}
              >
                <Icon size={18} strokeWidth={1.75} style={{ color: "var(--cyan)" }} />
              </div>
              <div>
                <h3 className="font-display font-medium text-sm mb-1" style={{ color: "var(--text-hi)" }}>
                  {tool.title}
                </h3>
                <p className="text-xs leading-relaxed" style={{ color: "var(--text-mid)" }}>
                  {tool.description}
                </p>
                <span
                  className="inline-block mt-2 font-mono text-[10px] tracking-wider px-2 py-0.5 rounded"
                  style={{ color: "var(--text-low)", background: "var(--panel-raised)" }}
                >
                  YAKINDA
                </span>
              </div>
            </div>
          );
        })}
      </div>

      <div
        className="mt-6 p-4 rounded-xl border font-mono text-[12px] leading-relaxed"
        style={{ background: "var(--panel)", borderColor: "var(--line)", color: "var(--text-low)" }}
      >
        Bu sayfa modüler tasarlandı: yeni bir araç eklemek için sadece kod tabanındaki
        modül listesine bir kayıt eklemek yeterli.
      </div>
    </div>
  );
}
