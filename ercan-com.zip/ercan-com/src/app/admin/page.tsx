"use client";

import { useEffect, useState } from "react";
import { ShieldCheck, CreditCard, Sparkles, Save, Check, Lock } from "lucide-react";
import PageHeader from "@/components/PageHeader";

interface SettingsState {
  iyzicoApiKey: string;
  iyzicoSecretKey: string;
  paytrMerchantId: string;
  videoAiProvider: string;
  videoAiApiKey: string;
  imageAiProvider: string;
  imageAiApiKey: string;
}

const EMPTY: SettingsState = {
  iyzicoApiKey: "",
  iyzicoSecretKey: "",
  paytrMerchantId: "",
  videoAiProvider: "runway",
  videoAiApiKey: "",
  imageAiProvider: "stability",
  imageAiApiKey: "",
};

export default function AdminPage() {
  const [masked, setMasked] = useState<Record<string, string>>({});
  const [connected, setConnected] = useState<Record<string, boolean>>({});
  const [form, setForm] = useState<SettingsState>(EMPTY);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/admin/settings")
      .then((r) => r.json())
      .then((data) => {
        setMasked(data);
        setConnected(data.connected ?? {});
        setForm((f) => ({
          ...f,
          videoAiProvider: data.videoAiProvider || "runway",
          imageAiProvider: data.imageAiProvider || "stability",
        }));
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  function update<K extends keyof SettingsState>(key: K, value: string) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSave() {
    setSaving(true);
    setSaved(false);
    try {
      const res = await fetch("/api/admin/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (res.ok) {
        setSaved(true);
        const refreshed = await fetch("/api/admin/settings").then((r) => r.json());
        setMasked(refreshed);
        setConnected(refreshed.connected ?? {});
        setForm((f) => ({
          ...f,
          iyzicoApiKey: "",
          iyzicoSecretKey: "",
          paytrMerchantId: "",
          videoAiApiKey: "",
          imageAiApiKey: "",
        }));
      }
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <PageHeader
        icon={ShieldCheck}
        eyebrow="YÖNETİM"
        title="Yönetim Paneli"
        description="Ödeme sağlayıcısı ve yapay zeka servis anahtarlarını buradan bağla. Anahtarlar sunucuda saklanır, sayfada her zaman maskelenmiş gösterilir."
      />

      {loading ? (
        <p className="text-sm" style={{ color: "var(--text-mid)" }}>Yükleniyor…</p>
      ) : (
        <div className="space-y-6">
          {/* Ödeme sağlayıcıları */}
          <section className="p-6 rounded-xl border" style={{ background: "var(--panel)", borderColor: "var(--line)" }}>
            <div className="flex items-center gap-2 mb-1">
              <CreditCard size={18} style={{ color: "var(--cyan)" }} />
              <h2 className="font-display font-medium text-base" style={{ color: "var(--text-hi)" }}>
                Ödeme Sağlayıcıları
              </h2>
            </div>
            <p className="text-xs mb-5" style={{ color: "var(--text-mid)" }}>
              Kart tahsilatı için iyzico veya PayTR hesabından alacağın API bilgilerini gir.
              Hesabın yoksa önce ilgili sağlayıcıda işyeri hesabı açman gerekir.
            </p>

            <div className="grid sm:grid-cols-2 gap-5">
              <div>
                <h3 className="font-mono text-[11px] tracking-wider mb-3 flex items-center gap-2" style={{ color: "var(--text-low)" }}>
                  IYZICO
                  {connected.iyzico && (
                    <span className="flex items-center gap-1" style={{ color: "var(--ok)" }}>
                      <Check size={12} /> BAĞLI
                    </span>
                  )}
                </h3>
                <div className="space-y-2.5">
                  <Field
                    label="API Key"
                    placeholder={masked.iyzicoApiKey || "sk_live_..."}
                    value={form.iyzicoApiKey}
                    onChange={(v) => update("iyzicoApiKey", v)}
                  />
                  <Field
                    label="Secret Key"
                    placeholder={masked.iyzicoSecretKey || "sk_secret_..."}
                    value={form.iyzicoSecretKey}
                    onChange={(v) => update("iyzicoSecretKey", v)}
                    secret
                  />
                </div>
              </div>

              <div>
                <h3 className="font-mono text-[11px] tracking-wider mb-3 flex items-center gap-2" style={{ color: "var(--text-low)" }}>
                  PAYTR
                  {connected.paytr && (
                    <span className="flex items-center gap-1" style={{ color: "var(--ok)" }}>
                      <Check size={12} /> BAĞLI
                    </span>
                  )}
                </h3>
                <div className="space-y-2.5">
                  <Field
                    label="Mağaza No (Merchant ID)"
                    placeholder={masked.paytrMerchantId || "123456"}
                    value={form.paytrMerchantId}
                    onChange={(v) => update("paytrMerchantId", v)}
                  />
                </div>
              </div>
            </div>
          </section>

          {/* AI servisleri */}
          <section className="p-6 rounded-xl border" style={{ background: "var(--panel)", borderColor: "var(--line)" }}>
            <div className="flex items-center gap-2 mb-1">
              <Sparkles size={18} style={{ color: "var(--violet)" }} />
              <h2 className="font-display font-medium text-base" style={{ color: "var(--text-hi)" }}>
                Yapay Zeka Servisleri
              </h2>
            </div>
            <p className="text-xs mb-5" style={{ color: "var(--text-mid)" }}>
              AI Video ve AI Karakter modüllerinin çalışması için ilgili servisten aldığın
              API anahtarını gir.
            </p>

            <div className="grid sm:grid-cols-2 gap-5">
              <div>
                <h3 className="font-mono text-[11px] tracking-wider mb-3 flex items-center gap-2" style={{ color: "var(--text-low)" }}>
                  VİDEO ÜRETİM SERVİSİ
                  {connected.videoAi && (
                    <span className="flex items-center gap-1" style={{ color: "var(--ok)" }}>
                      <Check size={12} /> BAĞLI
                    </span>
                  )}
                </h3>
                <div className="space-y-2.5">
                  <div>
                    <label className="text-xs block mb-1.5" style={{ color: "var(--text-mid)" }}>Sağlayıcı</label>
                    <select
                      value={form.videoAiProvider}
                      onChange={(e) => update("videoAiProvider", e.target.value)}
                      className="w-full rounded-lg border px-3 py-2 text-sm focus:outline-none"
                      style={{ background: "var(--panel-raised)", borderColor: "var(--line)", color: "var(--text-hi)" }}
                    >
                      <option value="runway">Runway</option>
                      <option value="pika">Pika Labs</option>
                      <option value="kling">Kling AI</option>
                    </select>
                  </div>
                  <Field
                    label="API Key"
                    placeholder={masked.videoAiApiKey || "API anahtarını yapıştır"}
                    value={form.videoAiApiKey}
                    onChange={(v) => update("videoAiApiKey", v)}
                    secret
                  />
                </div>
              </div>

              <div>
                <h3 className="font-mono text-[11px] tracking-wider mb-3 flex items-center gap-2" style={{ color: "var(--text-low)" }}>
                  GÖRSEL / KARAKTER SERVİSİ
                  {connected.imageAi && (
                    <span className="flex items-center gap-1" style={{ color: "var(--ok)" }}>
                      <Check size={12} /> BAĞLI
                    </span>
                  )}
                </h3>
                <div className="space-y-2.5">
                  <div>
                    <label className="text-xs block mb-1.5" style={{ color: "var(--text-mid)" }}>Sağlayıcı</label>
                    <select
                      value={form.imageAiProvider}
                      onChange={(e) => update("imageAiProvider", e.target.value)}
                      className="w-full rounded-lg border px-3 py-2 text-sm focus:outline-none"
                      style={{ background: "var(--panel-raised)", borderColor: "var(--line)", color: "var(--text-hi)" }}
                    >
                      <option value="stability">Stability AI</option>
                      <option value="replicate">Replicate</option>
                      <option value="openai">OpenAI (DALL·E)</option>
                    </select>
                  </div>
                  <Field
                    label="API Key"
                    placeholder={masked.imageAiApiKey || "API anahtarını yapıştır"}
                    value={form.imageAiApiKey}
                    onChange={(v) => update("imageAiApiKey", v)}
                    secret
                  />
                </div>
              </div>
            </div>
          </section>

          <div className="flex items-center gap-3">
            <button
              onClick={handleSave}
              disabled={saving}
              className="flex items-center gap-2 px-5 py-2.5 rounded-md font-medium text-sm transition-opacity hover:opacity-90 disabled:opacity-50"
              style={{ background: "var(--cyan)", color: "#06090f" }}
            >
              <Save size={16} />
              {saving ? "Kaydediliyor…" : "Ayarları Kaydet"}
            </button>
            {saved && (
              <span className="flex items-center gap-1.5 text-sm" style={{ color: "var(--ok)" }}>
                <Check size={15} /> Kaydedildi
              </span>
            )}
          </div>

          <div
            className="p-4 rounded-xl border flex items-start gap-3 font-mono text-[11px] leading-relaxed"
            style={{ background: "var(--panel)", borderColor: "var(--line)", color: "var(--text-low)" }}
          >
            <Lock size={14} className="shrink-0 mt-0.5" />
            Anahtarlar sunucu tarafında bir dosyada saklanır ve tarayıcıya asla açık biçimde
            geri gönderilmez. Canlıya alırken bu dosyanın yerine Vercel/Modal gibi platformların
            "secret" yönetim sistemini kullanman önerilir.
          </div>
        </div>
      )}
    </div>
  );
}

function Field({
  label,
  placeholder,
  value,
  onChange,
  secret = false,
}: {
  label: string;
  placeholder: string;
  value: string;
  onChange: (v: string) => void;
  secret?: boolean;
}) {
  return (
    <div>
      <label className="text-xs block mb-1.5" style={{ color: "var(--text-mid)" }}>{label}</label>
      <input
        type={secret ? "password" : "text"}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full rounded-lg border px-3 py-2 text-sm font-mono focus:outline-none"
        style={{ background: "var(--panel-raised)", borderColor: "var(--line)", color: "var(--text-hi)" }}
      />
    </div>
  );
}
