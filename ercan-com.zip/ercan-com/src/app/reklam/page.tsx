import { Megaphone, Plus, Eye, MousePointerClick } from "lucide-react";
import PageHeader from "@/components/PageHeader";

const SLOTS = [
  { id: 1, name: "Ana Sayfa — Üst Banner", price: "₺199/hafta", status: "boş", views: "—" },
  { id: 2, name: "Mağaza — Yan Panel", price: "₺99/hafta", status: "boş", views: "—" },
  { id: 3, name: "AI Video Sayfası — Alt Banner", price: "₺149/hafta", status: "boş", views: "—" },
];

export default function ReklamPage() {
  return (
    <div>
      <PageHeader
        icon={Megaphone}
        eyebrow="MODÜL 05"
        title="Ücretli Reklam Ekranı"
        description="Platform içindeki reklam alanlarını yönet. Reklam satın alındığında ödeme onaylandıktan sonra otomatik olarak yayına girer."
        accent="#f5a623"
      />

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        <div className="p-4 rounded-xl border" style={{ background: "var(--panel)", borderColor: "var(--line)" }}>
          <Eye size={16} style={{ color: "var(--amber)" }} />
          <div className="font-display font-semibold text-xl mt-3" style={{ color: "var(--text-hi)" }}>0</div>
          <div className="font-mono text-[10px] tracking-wider mt-1" style={{ color: "var(--text-low)" }}>TOPLAM GÖRÜNTÜLENME</div>
        </div>
        <div className="p-4 rounded-xl border" style={{ background: "var(--panel)", borderColor: "var(--line)" }}>
          <MousePointerClick size={16} style={{ color: "var(--amber)" }} />
          <div className="font-display font-semibold text-xl mt-3" style={{ color: "var(--text-hi)" }}>0</div>
          <div className="font-mono text-[10px] tracking-wider mt-1" style={{ color: "var(--text-low)" }}>TOPLAM TIKLAMA</div>
        </div>
        <div className="p-4 rounded-xl border" style={{ background: "var(--panel)", borderColor: "var(--line)" }}>
          <Megaphone size={16} style={{ color: "var(--amber)" }} />
          <div className="font-display font-semibold text-xl mt-3" style={{ color: "var(--text-hi)" }}>0 / 3</div>
          <div className="font-mono text-[10px] tracking-wider mt-1" style={{ color: "var(--text-low)" }}>DOLU ALAN</div>
        </div>
      </div>

      <div className="flex items-center justify-between mb-4">
        <h2 className="font-display font-medium text-base" style={{ color: "var(--text-hi)" }}>
          Reklam Alanları
        </h2>
        <button
          className="flex items-center gap-1.5 text-xs font-medium px-3 py-2 rounded-md"
          style={{ background: "var(--amber)", color: "#1a1206" }}
        >
          <Plus size={14} />
          Yeni alan ekle
        </button>
      </div>

      <div className="rounded-xl border overflow-hidden" style={{ borderColor: "var(--line)" }}>
        <table className="w-full text-sm">
          <thead>
            <tr style={{ background: "var(--panel-raised)" }}>
              <th className="text-left px-4 py-3 font-mono text-[10px] tracking-wider" style={{ color: "var(--text-low)" }}>ALAN</th>
              <th className="text-left px-4 py-3 font-mono text-[10px] tracking-wider" style={{ color: "var(--text-low)" }}>FİYAT</th>
              <th className="text-left px-4 py-3 font-mono text-[10px] tracking-wider" style={{ color: "var(--text-low)" }}>DURUM</th>
              <th className="text-right px-4 py-3 font-mono text-[10px] tracking-wider" style={{ color: "var(--text-low)" }}>İŞLEM</th>
            </tr>
          </thead>
          <tbody>
            {SLOTS.map((s) => (
              <tr key={s.id} className="border-t" style={{ borderColor: "var(--line)", background: "var(--panel)" }}>
                <td className="px-4 py-3.5" style={{ color: "var(--text-hi)" }}>{s.name}</td>
                <td className="px-4 py-3.5 font-mono" style={{ color: "var(--amber)" }}>{s.price}</td>
                <td className="px-4 py-3.5">
                  <span className="font-mono text-[10px] px-2 py-0.5 rounded" style={{ color: "var(--text-low)", background: "var(--panel-raised)" }}>
                    BOŞ
                  </span>
                </td>
                <td className="px-4 py-3.5 text-right">
                  <button className="text-xs underline" style={{ color: "var(--cyan)" }}>Satışa aç</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
