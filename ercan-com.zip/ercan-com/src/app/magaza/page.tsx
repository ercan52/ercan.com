import { LayoutTemplate, Download, Eye } from "lucide-react";
import PageHeader from "@/components/PageHeader";

const TEMPLATES = [
  { id: 1, name: "Komuta Paneli Pro", category: "Dashboard", price: "₺349", free: false },
  { id: 2, name: "Kurumsal Vitrin", category: "Kurumsal", price: "₺249", free: false },
  { id: 3, name: "Restoran Menü Sitesi", category: "Yeme-İçme", price: "₺199", free: false },
  { id: 4, name: "Kişisel Portfolyo", category: "Portfolyo", price: "Ücretsiz", free: true },
  { id: 5, name: "E-Ticaret Başlangıç", category: "E-Ticaret", price: "₺499", free: false },
  { id: 6, name: "Blog & İçerik", category: "Blog", price: "Ücretsiz", free: true },
  { id: 7, name: "Etkinlik Sayfası", category: "Etkinlik", price: "₺149", free: false },
  { id: 8, name: "Video Portalı (TV & FM tarzı)", category: "Medya", price: "₺399", free: false },
];

export default function MagazaPage() {
  return (
    <div>
      <PageHeader
        icon={LayoutTemplate}
        eyebrow="MODÜL 01"
        title="Web Şablonları Mağazası"
        description="Hazır şablonları indir, kendi markanla özelleştir, dakikalar içinde yayına al. Ücretli şablonlar satın alındığında indirme bağlantısı ödeme sonrası açılır."
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {TEMPLATES.map((t) => (
          <div
            key={t.id}
            className="rounded-xl border overflow-hidden flex flex-col"
            style={{ background: "var(--panel)", borderColor: "var(--line)" }}
          >
            <div
              className="h-32 flex items-center justify-center"
              style={{
                background:
                  "linear-gradient(135deg, rgba(0,229,255,0.08) 0%, rgba(139,92,246,0.08) 100%)",
              }}
            >
              <LayoutTemplate size={28} strokeWidth={1.5} style={{ color: "var(--cyan-dim)" }} />
            </div>
            <div className="p-4 flex-1 flex flex-col">
              <span className="font-mono text-[10px] tracking-wider mb-1.5" style={{ color: "var(--text-low)" }}>
                {t.category.toUpperCase()}
              </span>
              <h3 className="font-display font-medium text-sm mb-3" style={{ color: "var(--text-hi)" }}>
                {t.name}
              </h3>
              <div className="mt-auto flex items-center justify-between">
                <span
                  className="font-mono text-sm"
                  style={{ color: t.free ? "var(--ok)" : "var(--amber)" }}
                >
                  {t.price}
                </span>
                <div className="flex items-center gap-1.5">
                  <button
                    className="p-1.5 rounded-md border"
                    style={{ borderColor: "var(--line)", color: "var(--text-mid)" }}
                    aria-label="Önizle"
                  >
                    <Eye size={14} />
                  </button>
                  <button
                    className="p-1.5 rounded-md"
                    style={{ background: "var(--cyan)", color: "#06090f" }}
                    aria-label={t.free ? "İndir" : "Satın al"}
                  >
                    <Download size={14} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div
        className="mt-8 p-5 rounded-xl border font-mono text-[12px] leading-relaxed"
        style={{ background: "var(--panel)", borderColor: "var(--line)", color: "var(--text-low)" }}
      >
        NOT: Bu liste örnek veridir. Gerçek şablon dosyalarını ve fiyatları yönetim panelinden
        ekleyip düzenleyebilirsin.
      </div>
    </div>
  );
}
